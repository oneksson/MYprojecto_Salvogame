package com.codeoftheweb;
/*
public class jojo {
    {
        "id" : 1,
            "created" : "2018-09-11T18:30:05.717+0000",
            "gamePlayers" : [ {
        "id" : 1,
                "player" : {
            "id" : 1,
                    "email" : "Nahu",
                    "scores" : {
                "total" : 2.0,
                        "won" : 2,
                        "lost" : 0,
                        "tied" : 0
            }
        }
    }, {
        "id" : 2,
                "player" : {
            "id" : 2,
                    "email" : "jojo",
                    "scores" : {
                "total" : 0.0,
                        "won" : 0,
                        "lost" : 2,
                        "tied" : 0
            }
        }
    } ],
        "ships" : [ {
        "type" : "submarine",
                "locations" : [ "B5", "B6", "B7", "B8", "B9" ]
    }, {
        "type" : "helicopter",
                "locations" : [ "F3", "G3", "H3" ]
    } ],
        "salvoes" : [ {
        "turn" : 1,
                "player" : 1,
                "locations" : [ "B5", "B6" ]
    }, {
        "turn" : 2,
                "player" : 1,
                "locations" : [ "F3", "B5" ]
    }, {
        "turn" : 2,
                "player" : 2,
                "locations" : [ "C4", "A8" ]
    }, {
        "turn" : 1,
                "player" : 2,
                "locations" : [ "B3", "A6" ]
    } ]
    }
}
*/